import ast,json,pathlib
root=pathlib.Path(__file__).resolve().parents[1]
translations={};ctx='';text='';mode=''
for line in (root/'source/upstream/fdmprinter-es.po').read_text().splitlines()+['']:
    if line.startswith('msgctxt '):ctx=ast.literal_eval(line[8:]);mode='ctx'
    elif line.startswith('msgstr '):text=ast.literal_eval(line[7:]);mode='str'
    elif line.startswith('"') and mode=='str':text+=ast.literal_eval(line)
    elif not line:
        if ctx and text:translations[ctx]=text
        ctx=text=mode=''
    elif line.startswith('msgid '):mode='id'
printer=json.loads((root/'node_modules/cura-wasm/src/definitions/fdmprinter.def.json').read_text())
extruder=json.loads((root/'node_modules/cura-wasm/src/definitions/fdmextruder.def.json').read_text())
profile=json.loads((root/'dist/ender.json').read_text())
categories=[];settings={}
def walk(nodes,category):
    for key,node in nodes.items():
        if node.get('type')=='category':
            category=key
            if not any(c['key']==key for c in categories):categories.append({'key':key,'label':translations.get(key+' label',node.get('label',key))})
        else:
            item={k:v for k,v in node.items() if k!='children'}
            item.update(key=key,category=category)
            if key in settings:settings[key].update(item)
            else:settings[key]=item
            settings[key]['label']=translations.get(key+' label',node.get('label',key))
            settings[key]['description']=translations.get(key+' description',node.get('description',''))
            if node.get('options'):settings[key]['optionLabels']={k:translations.get(key+' option '+k,v) for k,v in node['options'].items()}
        if node.get('children'):walk(node['children'],category)
walk(printer['settings'],None);walk(extruder['settings'],None)
(root/'src/catalog.json').write_text(json.dumps({'categories':categories,'settings':settings},ensure_ascii=False,separators=(',',':')))
print(len(settings),'parámetros en',len(categories),'categorías')

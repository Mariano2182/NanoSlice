import {activeFilament,validateMaterialTemperatures}from './filaments.js';
import {machine}from './machine.js';
import {catalog,basicKeys,lockedReason,parseSetting,resolveSettings,encodeOverrides,cleanOverrides,settingBounds,validateSettingsOverrides}from './settings.js';
const $=id=>document.getElementById(id);let extra={},baseGetter,onEdit,downloadUrl;let advancedStorage='nanoslice-advanced-v1';
try{extra=cleanOverrides(JSON.parse(localStorage.getItem('nanoslice-advanced-v1')||'{}'))}catch{}
function store(){try{localStorage.setItem(advancedStorage,JSON.stringify(extra))}catch{$('advancedMessage').textContent='El navegador no permite guardar el perfil.'}}
function base(){return baseGetter()}
function merged(){return {...base(),...extra}}
export function engineSettings(b){
 const all={...b,...extra};const r=resolveSettings(all);validateMaterialTemperatures(r.values,machine);
 if(Object.keys(r.errors).length)throw Error('No se pudieron resolver: '+Object.keys(r.errors).join(', '));
 // Limits that depend on other settings are checked on explicit user overrides.
 validateSettingsOverrides(extra,r);
 for(const [key,value]of Object.entries(r.values))if(typeof value==='number'&&!Number.isFinite(value))throw Error('Valor inválido: '+key);
 // Expand Cura placeholders in customized start/end code using the resolved profile.
 for(const key of ['machine_start_gcode','machine_end_gcode'])r.values[key]=String(r.values[key]).replace(/\{([a-zA-Z_][\w]*)\}/g,(m,k)=>Object.hasOwn(r.values,k)?String(r.values[k]):m);
 return encodeOverrides(r.values);
}
export function basicEdited(id){for(const[key,bid]of Object.entries(basicKeys))if(bid===id)delete extra[key];if(id==='top')delete extra.bottom_layers;store();refreshAdvanced()}
export function applySuggestedSettings(){for(const key of [...Object.keys(basicKeys),'bottom_layers','brim_width','support_angle'])delete extra[key];store();refreshAdvanced()}
function validateBasicValue(key,value){const linked=basicKeys[key];if(linked&&$(linked).type==='number'){const el=$(linked),old=el.value;el.value=String(value);const valid=el.checkValidity();el.value=old;if(!valid)throw Error('El perfil básico admite '+(el.min||'sin mínimo')+' a '+(el.max||'sin máximo')+' '+(catalog.settings[key].unit||''))}}
function setExtra(key,value,batch=false){validateBasicValue(key,value);if(!batch)validateSettingsOverrides({...extra,[key]:value},resolveSettings({...base(),...extra,[key]:value}));extra[key]=value;const id=basicKeys[key];if(id){const el=$(id);if(el.type==='checkbox')el.checked=value;else if(el.tagName==='SELECT'&&!Array.from(el.options).some(o=>o.value===String(value))){const option=new Option(String(value)+' · avanzado',String(value));el.add(option);el.value=String(value)}else el.value=value;}if(!batch){store();onEdit();refreshAdvanced()}}
function normalize(t){return String(t).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase()}
export function refreshAdvanced(){
 if(!baseGetter||!$('advancedPanel').open)return;
 const r=resolveSettings(merged()),category=$('advancedCategory').value,query=normalize($('advancedSearch').value),only=$('onlyModified').checked;
 const entries=Object.values(catalog.settings).filter(s=>(category==='all'||s.category===category)&&(!only||Object.hasOwn(extra,s.key))&&(!query||normalize(s.label+' '+s.key+' '+s.description).includes(query)));
 $('advancedCount').textContent=entries.length+' de '+Object.keys(catalog.settings).length+' parámetros · '+Object.keys(extra).length+' personalizados';$('advancedList').replaceChildren();
 for(const s of entries){const row=document.createElement('article');row.className='parameter';const locked=lockedReason(s),val=r.values[s.key],custom=Object.hasOwn(extra,s.key),enabled=r.enabled(s.key);const label=document.createElement('label');label.htmlFor='setting-'+s.key;label.textContent=s.label+(s.unit?' ('+s.unit+')':'');row.append(label);const code=document.createElement('code');code.textContent=s.key;row.append(code);
 const control=document.createElement(s.type==='enum'||s.type==='bool'?'select':['str','polygon','polygons','[int]'].includes(s.type)?'textarea':'input');control.id='setting-'+s.key;
 if(s.type==='enum')for(const [key,text]of Object.entries(s.options||{}))control.add(new Option(s.optionLabels?.[key]||text,key));
 else if(s.type==='bool'){control.add(new Option('Sí','true'));control.add(new Option('No','false'));}
 else if(['int','float','extruder','optional_extruder'].includes(s.type)){control.type='number';control.step=s.type==='float'?'any':'1'}
 if(control.tagName==='TEXTAREA')control.rows=s.key.includes('gcode')?6:2;
 control.value=Array.isArray(val)?JSON.stringify(val):String(val??'');control.disabled=Boolean(locked);
 control.onchange=()=>{try{const value=parseSetting(s,control.value);setExtra(s.key,value);$('advancedMessage').textContent=s.label+': guardado. Volvé a laminar.'}catch(e){$('advancedMessage').textContent=s.label+': '+e.message;control.value=Array.isArray(val)?JSON.stringify(val):String(val??'')}};
 row.append(control);const bounds=settingBounds(s,r);if(control.type==='number'){if(bounds.min!==null)control.min=bounds.min;if(bounds.max!==null)control.max=bounds.max}const warning=typeof val==='number'&&((bounds.warningMin!==null&&val<bounds.warningMin)||(bounds.warningMax!==null&&val>bounds.warningMax));const state=document.createElement('small');state.textContent=locked?'Solo lectura · perfil original':(custom?'Valor personalizado':'Valor del perfil / calculado')+(enabled===false?' · no activo con la configuración actual':enabled===null?' · condición de activación no evaluada':'');if(warning){state.textContent+=' · fuera del rango recomendado por Cura';state.className='parameterWarning'}row.append(state);
 const detail=document.createElement('details'),summary=document.createElement('summary'),desc=document.createElement('p');summary.textContent='Descripción y dependencias';desc.textContent=s.description;detail.append(summary,desc);if(s.value!==undefined){const formula=document.createElement('p');formula.className='formula';formula.textContent='Valor automático: '+JSON.stringify(s.value);detail.append(formula)}if(s.enabled!==undefined){const condition=document.createElement('p');condition.className='formula';condition.textContent='Condición: '+s.enabled;detail.append(condition)}if(locked){const reason=document.createElement('p');reason.textContent=locked;detail.append(reason)}row.append(detail);
 if(custom&&!locked){row.classList.add('custom');const reset=document.createElement('button');reset.textContent='Restaurar este parámetro';reset.onclick=()=>{const id=basicKeys[s.key];if(id){const defaults={layer:'0.2',infill:'20',temp:'200',bed:'60',speed:'50',support:false,walls:'2',top:'4',adhesion:'skirt'};if($(id).type==='checkbox')$(id).checked=defaults[id];else $(id).value=defaults[id]}delete extra[s.key];store();onEdit();refreshAdvanced()};row.append(reset)}$('advancedList').append(row);
 }
 if(!entries.length)$('advancedList').textContent='No hay parámetros con esos filtros.';
}
export function setupAdvanced(getter,edited){baseGetter=getter;onEdit=edited;for(const[key,id]of Object.entries(basicKeys))if(catalog.settings[key].type==='float'&&$(id).type==='number')$(id).step='any';for(const c of catalog.categories)$('advancedCategory').add(new Option(c.label,c.key));$('advancedCategory').value='resolution';$('advancedPanel').ontoggle=refreshAdvanced;$('advancedSearch').oninput=()=>{if($('advancedSearch').value)$('advancedCategory').value='all';refreshAdvanced()};$('advancedCategory').onchange=refreshAdvanced;$('onlyModified').onchange=refreshAdvanced;
 $('resetAdvanced').onclick=()=>{extra={};store();onEdit();refreshAdvanced();$('advancedMessage').textContent='Personalizaciones avanzadas eliminadas. Se conservan los controles básicos.'};
 $('exportProfile').onclick=()=>{if(downloadUrl)URL.revokeObjectURL(downloadUrl);const data={format:'nanoslice-profile',version:1,engine:'cura-wasm-1.5.2',machineId:machine.id,materialId:activeFilament.id,settings:{...Object.fromEntries(Object.entries(basicKeys).map(([key,id])=>[key,$(id).type==='checkbox'?$(id).checked:parseSetting(catalog.settings[key],$(id).value)])),...extra}};downloadUrl=URL.createObjectURL(new Blob([JSON.stringify(data,null,2)],{type:'application/json'}));const a=document.createElement('a');a.href=downloadUrl;a.download='NanoSlice-perfil.json';a.click()};
 $('importProfile').onchange=async event=>{const f=event.target.files[0];if(!f)return;try{if(f.size>1000000)throw Error('El perfil supera 1 MB.');const data=JSON.parse(await f.text());if(data.format!=='nanoslice-profile'||data.version!==1||data.engine!=='cura-wasm-1.5.2')throw Error('Usá un perfil JSON exportado por esta versión de NanoSlice.');if(data.machineId&&data.machineId!==machine.id)throw Error('El perfil pertenece a otra impresora. Seleccioná primero esa máquina.');if(data.materialId&&data.materialId!==activeFilament.id)throw Error('El perfil pertenece a otro filamento. Activá primero ese material.');const clean=cleanOverrides(data.settings);validateSettingsOverrides(clean,resolveSettings({...base(),...clean}));for(const[key,value]of Object.entries(clean))validateBasicValue(key,value);extra={};for(const[key,value]of Object.entries(clean))setExtra(key,value,true);store();onEdit();refreshAdvanced();$('advancedMessage').textContent='Perfil importado. Revisá los ajustes y volvé a laminar.'}catch(e){$('advancedMessage').textContent='No se pudo importar: '+e.message}event.target.value=''};
 mirrorAdvancedToBasic();
}

export function switchAdvancedMachine(){store();advancedStorage=activeFilament.id==='PLA'?(machine.id==='nano_ender3v2'?'nanoslice-advanced-v1':'nanoslice-advanced-'+machine.id):'nanoslice-advanced-'+machine.id+'-'+activeFilament.id;try{extra=cleanOverrides(JSON.parse(localStorage.getItem(advancedStorage)||'{}'))}catch{extra={}}mirrorAdvancedToBasic();refreshAdvanced();}

function mirrorAdvancedToBasic(){

 for(const[key,value]of Object.entries(extra)){const id=basicKeys[key];if(id){const el=$(id);if(el.type==='checkbox')el.checked=value;else{if(el.tagName==='SELECT'&&!Array.from(el.options).some(o=>o.value===String(value)))el.add(new Option(String(value)+' · avanzado',String(value)));el.value=value}}}
}

export function clearMaterialOverrides(){for(const key of Object.keys(extra))if(key.startsWith('material_')||key.startsWith('cool_')||key.startsWith('retraction_')||['speed_print','speed_layer_0','speed_print_layer_0','speed_travel_layer_0','skirt_brim_speed','adhesion_type'].includes(key))delete extra[key];store();refreshAdvanced();}

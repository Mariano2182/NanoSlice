// Restricted interpreter for the Python-style expressions in the bundled Cura definitions.
// No eval, Function constructor, attribute access or user-defined code execution.
const asts=new Map();
export function parseExpression(source){
 if(asts.has(source))return asts.get(source);
 const tokens=[];const re=/\s*(?:(\d+(?:\.\d*)?(?:[eE][+-]?\d+)?|\.\d+)|('(?:\\.|[^'\\])*'|"(?:\\.|[^"\\])*")|([A-Za-z_][A-Za-z_0-9.]*)|(==|!=|<=|>=|\*\*|\/\/|[+\-*\/%<>()\[\],]))/y;let pos=0;
 while(pos<source.length){re.lastIndex=pos;const m=re.exec(source);if(!m)throw Error('Expresión no admitida: '+source.slice(pos));tokens.push(m[1]?{type:'literal',value:Number(m[1])}:m[2]?{type:'literal',value:m[2].slice(1,-1).replace(/\\(['"\\])/g,'$1')}:m[3]?{type:'word',value:m[3]}:{type:'op',value:m[4]});pos=re.lastIndex}
 let i=0;const peek=v=>tokens[i]?.value===v,take=v=>{if(!peek(v))throw Error('Se esperaba '+v);i++};
 function atom(){const t=tokens[i++];if(!t)throw Error('Expresión incompleta');if(t.type==='literal')return ['literal',t.value];if(t.value==='('){const n=conditional();take(')');return n}if(t.value==='['){const args=[];if(!peek(']')){do{args.push(conditional());if(!peek(','))break;i++}while(!peek(']'))}take(']');return ['list',args]}if(['True','False','None'].includes(t.value))return ['literal',t.value==='True'?true:t.value==='False'?false:null];if(t.type!=='word')throw Error('Símbolo inválido');if(peek('(')){i++;const args=[];if(!peek(')')){do{args.push(conditional());if(!peek(','))break;i++}while(!peek(')'))}take(')');return ['call',t.value,args]}return ['name',t.value]}
 function unary(){if(peek('+')||peek('-')||peek('not'))return ['unary',tokens[i++].value,unary()];return atom()}
 function power(){let n=unary();if(peek('**')){i++;n=['binary','**',n,power()]}return n}
 function mul(){let n=power();while(['*','/','//','%'].includes(tokens[i]?.value))n=['binary',tokens[i++].value,n,power()];return n}
 function add(){let n=mul();while(['+','-'].includes(tokens[i]?.value))n=['binary',tokens[i++].value,n,mul()];return n}
 function compare(){let n=add();while(['==','!=','<','>','<=','>=','in'].includes(tokens[i]?.value))n=['binary',tokens[i++].value,n,add()];return n}
 function and(){let n=compare();while(peek('and')){i++;n=['binary','and',n,compare()]}return n}
 function or(){let n=and();while(peek('or')){i++;n=['binary','or',n,and()]}return n}
 function conditional(){const yes=or();if(peek('if')){i++;const test=or();take('else');return ['if',test,yes,conditional()]}return yes}
 const result=conditional();if(i!==tokens.length)throw Error('Expresión no admitida');asts.set(source,result);return result;
}
export function evaluateExpression(source,lookup){
 const reducers={min:a=>Math.min(...a),max:a=>Math.max(...a),sum:a=>a.reduce((s,v)=>s+v,0),any:a=>a.some(Boolean),all:a=>a.every(Boolean)};
 const functions={abs:Math.abs,int:Math.trunc,float:Number,bool:Boolean,round:(n,d=0)=>Math.round(n*10**d)/10**d,'math.atan':Math.atan,'math.degrees':n=>n*180/Math.PI,'math.ceil':Math.ceil,'math.floor':Math.floor,'math.tan':Math.tan,'math.radians':n=>n*Math.PI/180,'math.sqrt':Math.sqrt,'math.sin':Math.sin,'math.cos':Math.cos,resolveOrValue:lookup,extruderValue:(_,key)=>lookup(key),extruderValues:key=>[lookup(key)],defaultExtruderPosition:()=>0,map:(fn,a)=>{if(fn!=='abs')throw Error('Función no admitida');return a.map(Math.abs)}};
 function run(n){const[t,a,b,c]=n;if(t==='literal')return a;if(t==='name'){if(a==='math.pi')return Math.PI;if(a==='abs')return 'abs';return lookup(a)}if(t==='list')return a.map(run);if(t==='if')return run(a)?run(b):run(c);if(t==='unary'){const v=run(b);return a==='not'?!v:a==='-'?-v:+v}if(t==='call'){const args=b.map(run);if(reducers[a])return reducers[a](args.length===1&&Array.isArray(args[0])?args[0]:args);if(!functions[a])throw Error('Función no admitida: '+a);return functions[a](...args)}if(t==='binary'){const x=run(b);if(a==='and')return x&&run(c);if(a==='or')return x||run(c);const y=run(c);switch(a){case '+':return x+y;case '-':return x-y;case '*':return x*y;case '/':return x/y;case '//':return Math.floor(x/y);case '%':return x%y;case '**':return x**y;case '==':return x===y;case '!=':return x!==y;case '<':return x<y;case '>':return x>y;case '<=':return x<=y;case '>=':return x>=y;case 'in':return y.includes(x)}}throw Error('Expresión inválida')}
 return run(parseExpression(String(source)));
}

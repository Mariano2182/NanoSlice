// Generic starting profiles, not calibrated vendor profiles. Thermal family ranges:
// https://help.prusa3d.com/es/filament-material-guide (checked 2026-11-03).
// Speeds, fans and retraction values below are NanoSlice starting heuristics.
const guide='https://help.prusa3d.com/es/filament-material-guide';
const rows=[
 ['PLA','PLA',205,60,100,45,5,1,[185,235],[50,60],false,false,'Uso general. Calibrá temperatura y flujo con tu bobina.'],
 ['PLA_PLUS','PLA+',215,60,100,40,5,1,[185,235],[50,60],false,false,'PLA+ no es una formulación única: prevalecen los datos de la marca.'],
 ['PETG','PETG',235,80,35,40,4,.8,[215,270],[70,90],false,true,'Revisá adhesión y separación de la superficie; secá según el fabricante.'],
 ['ABS','ABS',245,100,0,40,4,1,[230,255],[95,110],true,true,'Controlá corrientes de aire y contracción. Seguí las indicaciones de ventilación del fabricante.'],
 ['ASA','ASA',255,105,0,40,4,1,[220,275],[90,110],true,true,'Revisá cerramiento, contracción y ventilación de acuerdo con el fabricante.'],
 ['TPU','TPU 95A',230,50,0,20,0,0,[220,260],[40,85],false,true,'Perfil lento con retracción desactivada como punto de partida. La dureza y el extrusor cambian el comportamiento.'],
 ['PA','PA / Nylon',260,90,10,30,4,1,[240,285],[70,115],true,true,'La familia PA tiene muchas formulaciones. Verificá humedad, hotend y superficie de adhesión.'],
 ['PC','PC / Policarbonato',275,110,15,30,3,1,[270,275],[100,115],true,true,'Material técnico: verificá equipo y temperaturas de tu formulación, especialmente PC Blend.'],
 ['PVA','PVA / BVOH',205,60,60,25,3,.8,[195,215],[60,60],false,true,'Soluble y sensible a humedad. En esta versión imprime todo el modelo con un solo material; no agrega soportes de otro filamento.'],
 ['HIPS','HIPS',240,100,0,35,4,1,[225,255],[100,110],true,true,'Revisá contracción y adhesión. No se implementa impresión combinada con otro material.'],
 ['PP','PP / Polipropileno',230,85,30,30,3,1,[220,245],[70,100],true,true,'Necesita una superficie de adhesión apropiada para PP; verificá el sistema indicado por tu proveedor.']
];
export const filaments=rows.map(([id,name,temp,bed,fan,speed,bowden,direct,tempRange,bedRange,enclosure,dry,notes])=>({id,family:id,name,brand:'Genérico',temp,bed,fan,speed,bowden,direct,retractSpeed:id==='TPU'?15:25,flow:100,tempRange,bedRange,enclosure,dry,abrasive:false,diameter:null,notes,source:guide,brim:['ABS','ASA','PA','PC','HIPS','PP'].includes(id)}));
export let activeFilament={...filaments[0]};
export function setActiveFilament(profile){activeFilament=validateFilament(profile)}
export function validateFilament(raw){
 if(!raw||typeof raw!=='object')throw Error('Perfil de filamento inválido.');const parent=filaments.find(p=>p.id===raw.family);if(!parent)throw Error('Familia de filamento no admitida.');const p={...parent};
 for(const key of ['name','brand','notes'])if(raw[key]!==undefined)p[key]=String(raw[key]).replace(/[\r\n]/g,' ').slice(0,key==='notes'?500:90);
 for(const[key,min,max]of [['temp',0,400],['bed',0,150],['fan',0,100],['speed',1,150],['bowden',0,15],['direct',0,15],['retractSpeed',1,80],['flow',50,150]]){const n=raw[key]===undefined?parent[key]:Number(raw[key]);if(!Number.isFinite(n)||n<min||n>max)throw Error('Valor inválido de '+key);p[key]=n}
 for(const key of ['abrasive','enclosure','dry','brim'])if(raw[key]!==undefined){if(typeof raw[key]!=='boolean')throw Error('Valor inválido de '+key);p[key]=raw[key]}
 p.diameter=raw.diameter===undefined||raw.diameter===null||raw.diameter===0?null:Number(raw.diameter);if(p.diameter!==null&&![1.75,2.85,3].includes(p.diameter))throw Error('Diámetro de bobina no admitido.');
 if(JSON.stringify(p)===JSON.stringify(parent))p.id=parent.id;else{let hash=2166136261;for(const c of JSON.stringify(p))hash=Math.imul(hash^c.charCodeAt(0),16777619);p.id='filament-'+(hash>>>0).toString(16)}return p;
}
export function defaultEquipment(printer){return {extruder:printer.id==='nano_ender3v2'?'bowden':'unknown',hotend:printer.id==='nano_ender3v2'?'ptfe':'unknown',enclosure:false,hardened:false}}
export function retractionFor(profile,equipment){return equipment.extruder==='bowden'?profile.bowden:profile.direct}
export function filamentEngineSettings(profile,equipment){const r=retractionFor(profile,equipment);return {cool_fan_enabled:profile.fan>0,cool_fan_speed:profile.fan,cool_fan_speed_min:profile.fan,cool_fan_speed_max:profile.fan,cool_fan_speed_0:0,cool_fan_full_layer:3,retraction_enable:r>0,retraction_amount:r,retraction_speed:profile.retractSpeed,material_flow:profile.flow}}
export function filamentCompatibility(profile,printer,equipment,{temp=profile.temp,bed=profile.bed}={}){
 const errors=[],warnings=[];
 if(temp>printer.maxTemp)errors.push('La propuesta de '+temp+' °C supera el límite de boquilla configurado ('+printer.maxTemp+' °C).');
 if(bed>printer.maxBed)errors.push('La propuesta de cama a '+bed+' °C supera el límite configurado ('+printer.maxBed+' °C).');
 if(bed>0&&!printer.heated)errors.push('Este perfil pide cama calefaccionada y la impresora está declarada sin ella.');
 if(profile.diameter!==null&&Math.abs(profile.diameter-printer.filament)>.01)errors.push('La bobina es de '+profile.diameter+' mm y el perfil de impresora está configurado para '+printer.filament+' mm.');
 if(profile.enclosure&&!equipment.enclosure)warnings.push('Se recomienda controlar el ambiente con cerramiento para este perfil.');
 if(profile.dry)warnings.push('Revisá secado y almacenamiento de acuerdo con el fabricante.');
 if(profile.abrasive&&!equipment.hardened)warnings.push('Material cargado: verificá una boquilla resistente a la abrasión.');
 if(profile.abrasive&&printer.nozzle<.4)warnings.push('Boquilla pequeña para un material cargado: comprobá el diámetro mínimo del fabricante.');
 if(temp>240&&equipment.hotend!=='allmetal')warnings.push('Temperatura elevada: comprobá el límite continuo del hotend y del conjunto PTFE con el fabricante.');
 if(profile.family==='TPU'&&equipment.extruder==='bowden')warnings.push('Flexible en Bowden: puede requerir más calibración y una alimentación guiada.');
 if(equipment.extruder==='unknown')warnings.push('Tipo de extrusor no declarado. La retracción inicial corta requiere calibración.');
 if(temp<profile.tempRange[0]||temp>profile.tempRange[1])warnings.push('Temperatura fuera del rango orientativo de la familia; prevalece la ficha de tu bobina.');
 return {errors,warnings};
}
export function validateMaterialTemperatures(values,printer){
 for(const[key,value]of Object.entries(values)){if(typeof value!=='number')continue;if(key.startsWith('material_')&&key.includes('temperature')&&!key.includes('bed')&&value>printer.maxTemp)throw Error(key+' supera el límite configurado de boquilla.');if(key.startsWith('material_bed_temperature')&&value>printer.maxBed)throw Error(key+' supera el límite configurado de cama.');if(key.startsWith('material_bed_temperature')&&value>0&&!printer.heated)throw Error('Se solicita calentar una cama declarada sin calefacción.');}
}
export function materializeRecommendation(proposal,profile){const result={...proposal,settings:{...proposal.settings}};result.settings.speed=String(Math.min(Number(result.settings.speed),profile.speed));if(profile.brim)result.settings.adhesion='brim';return result}

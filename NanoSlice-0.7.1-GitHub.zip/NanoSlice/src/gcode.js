import {insideMachine,defaultMachine} from './machine.js';
// Pure parser shared by the preview and regression checks. Positions in millimetres.
export function inspectGcode(text,printer=defaultMachine) {
  let x=0,y=0,z=0,e=0,absolute=true,absoluteE=true,layer=null,type='WALL',lineNumber=0;
  const layers=[], warnings=[];let outside=0,segments=0,extrusion=0,time=0,homed=false,heated=false,temperatureViolations=0;
  for (const raw of text.split(/\r?\n/)) {
    lineNumber++;
    if(raw.startsWith(';TIME:'))time=Number(raw.slice(6))||0;
    if(raw.startsWith(';TIME_ELAPSED:'))time=Number(raw.slice(14))||time;
    const match=raw.match(/^;LAYER:(-?\d+)/);
    if(match){layer={number:Number(match[1]),z,paths:[]};layers.push(layer)}
    if(raw.startsWith(';TYPE:'))type=raw.slice(6).trim();
    const code=raw.split(';')[0].trim().toUpperCase();if(!code)continue;
    const command=code.match(/^([GMT]\d+)/)?.[1];const args={};
    for(const m of code.matchAll(/([XYZEFSR])\s*(-?(?:\d+\.?\d*|\.\d+))/g))args[m[1]]=Number(m[2]);
    if(command==='G20')throw Error('El archivo usa pulgadas. Este visor admite G-code en milímetros.');
    if(command==='G28'){homed=true;x=y=z=0;continue}
    if(command==='G90'){absolute=true;continue}if(command==='G91'){absolute=false;continue}
    if(command==='M82'){absoluteE=true;continue}if(command==='M83'){absoluteE=false;continue}
    if(command==='M109')heated=true;const target=args.S??args.R;if(target!==undefined&&['M104','M109','M140','M190'].includes(command)){const bed=command==='M140'||command==='M190';if(target<0||target>(bed?printer.maxBed:printer.maxTemp)||bed&&target>0&&!printer.heated)temperatureViolations++;}
    if(command==='G92'){if(args.X!==undefined)x=args.X;if(args.Y!==undefined)y=args.Y;if(args.Z!==undefined)z=args.Z;if(args.E!==undefined)e=args.E;continue}
    if(command!=='G0'&&command!=='G1')continue;
    const nx=args.X===undefined?x:(absolute?args.X:x+args.X),ny=args.Y===undefined?y:(absolute?args.Y:y+args.Y),nz=args.Z===undefined?z:(absolute?args.Z:z+args.Z),ne=args.E===undefined?e:(absoluteE?args.E:e+args.E);
    if(!insideMachine(nx,ny,nz,printer))outside++;
    const distance=Math.hypot(nx-x,ny-y);
    if(layer&&ne>e&&distance>.0001){
      if(++segments>1500000)throw Error('Demasiadas trayectorias para la vista previa móvil. Reducí el tamaño del modelo.');
      layer.z=nz;layer.paths.push([x,y,nx,ny,type]);extrusion+=ne-e;
    }
    x=nx;y=ny;z=nz;e=ne;
  }
  if(!layers.length||!segments)throw Error('El archivo no contiene capas con extrusión.');
  if(outside)warnings.push(outside+' movimientos fuera del volumen de '+printer.name+'.');
  if(temperatureViolations)warnings.push(temperatureViolations+' órdenes de temperatura fuera de los límites configurados.');
  if(!homed)warnings.push('No se encontró la orden de origen G28.');
  if(!heated)warnings.push('No se encontró espera de temperatura M109.');
  return {layers,warnings,outside,temperatureViolations,segments,filamentMetres:extrusion/1000,time};
}

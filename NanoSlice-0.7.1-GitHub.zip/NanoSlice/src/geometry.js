import {Vector3} from 'three';
export function groundGeometry(geometry){
  geometry.computeBoundingBox();const box=geometry.boundingBox;
  const d=box.getSize(new Vector3());if(![d.x,d.y,d.z].every(v=>Number.isFinite(v)&&v>0))throw Error('El STL no tiene un volumen válido.');
  const center=box.getCenter(new Vector3());geometry.translate(-center.x,-center.y,-box.min.z);geometry.computeBoundingBox();geometry.computeVertexNormals();return geometry;
}
export function turnGeometry(geometry,axis){
  const g=geometry.clone();g.center();
  if(axis==='x')g.rotateX(Math.PI/2);else if(axis==='y')g.rotateY(Math.PI/2);else if(axis==='z')g.rotateZ(Math.PI/2);else throw Error('Eje inválido');
  return groundGeometry(g);
}

import {fitsMachine,defaultMachine} from './machine.js';
import {Vector3} from 'three';
import {groundGeometry} from './geometry.js';
const variants=[['actual',null,0],['X +90°','x',Math.PI/2],['X −90°','x',-Math.PI/2],['X 180°','x',Math.PI],['Y +90°','y',Math.PI/2],['Y −90°','y',-Math.PI/2]];
export function recommendPrint(input,scale=1,goal='balanced',printer=defaultMachine){
  if(!Number.isFinite(scale)||scale<=0)throw Error('Revisá la escala del modelo.');
  if(input.getAttribute('position').count>1500000)throw Error('Para sugerir orientación en el celular, usá un modelo con menos de 500.000 triángulos.');
  let best;
  for(const [label,axis,angle]of variants){
    const g=input.clone();g.scale(scale,scale,scale);g.center();if(axis)g['rotate'+axis.toUpperCase()](angle);groundGeometry(g);const d=g.boundingBox.getSize(new Vector3());
    if(!fitsMachine(d,printer)){g.dispose();continue}
    const p=g.getAttribute('position'),idx=g.index;let contact=0,overhang=0,total=0;
    const a=new Vector3(),b=new Vector3(),c=new Vector3(),ab=new Vector3(),ac=new Vector3(),normal=new Vector3();
    for(let i=0;i<(idx?idx.count:p.count);i+=3){
      a.fromBufferAttribute(p,idx?idx.getX(i):i);b.fromBufferAttribute(p,idx?idx.getX(i+1):i+1);c.fromBufferAttribute(p,idx?idx.getX(i+2):i+2);normal.crossVectors(ab.subVectors(b,a),ac.subVectors(c,a));const area=normal.length()/2;if(!area)continue;normal.normalize();total+=area;
      if(Math.max(a.z,b.z,c.z)<.08)contact+=area;
      // Conservative proxy: downward-facing facets steeper than a 45° overhang.
      // Does not test whether another part of the model supports a facet.
      else if(normal.z<-.7071&&Math.max(a.z,b.z,c.z)>.24)overhang+=area*-normal.z;
    }
    const footprint=d.x*d.y,base=contact/Math.max(footprint,1),risk=overhang/Math.max(total,1);
    const score=base*4-risk*8-d.z/printer.height;
    const item={label,axis,angle,dimensions:d.toArray(),contact,overhang,score,smallBase:base<.12||contact<80};g.dispose();if(!best||score>best.score+1e-7)best=item;
  }
  if(!best)throw Error('Ninguna de las seis orientaciones entra. Reducí la escala del modelo.');
  const presets={balanced:{layer:'0.2',infill:'20',speed:'45',walls:'3',top:'5'},strength:{layer:'0.2',infill:'40',speed:'40',walls:'4',top:'6'},finish:{layer:'0.12',infill:'20',speed:'35',walls:'3',top:'6'}};
  const preset={...(presets[goal]||presets.balanced)};preset.layer=String(Math.min(Number(preset.layer),Math.floor(printer.nozzle*.65*100)/100));
  return {...best,goal,settings:{...preset,support:best.overhang>1,adhesion:best.smallBase?'brim':'skirt'}};
}
export function applyRecommendedRotation(geometry,proposal){const g=geometry.clone();g.center();if(proposal.axis)g['rotate'+proposal.axis.toUpperCase()](proposal.angle);return groundGeometry(g)}

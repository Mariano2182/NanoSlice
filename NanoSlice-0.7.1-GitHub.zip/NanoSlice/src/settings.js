import rawCatalog from './catalog.json' with {type:'json'};
import {evaluateExpression} from './expression.js';
import enderOverrides from './ender-overrides.json' with {type:'json'};
export const catalog={categories:rawCatalog.categories,settings:{}};
export function configureSettingsProfile(overrides={}){catalog.settings=structuredClone(rawCatalog.settings);for(const[key,value]of Object.entries(overrides))if(catalog.settings[key])Object.assign(catalog.settings[key],value)}
configureSettingsProfile(enderOverrides);
export const basicKeys={layer_height:'layer',infill_sparse_density:'infill',material_print_temperature:'temp',material_bed_temperature:'bed',speed_print:'speed',support_enable:'support',wall_line_count:'walls',top_layers:'top',adhesion_type:'adhesion'};
export function lockedReason(s){if(['machine_start_gcode','machine_end_gcode'].includes(s.key))return '';if(s.category==='machine_settings'||s.category==='dual'||s.category==='command_line_settings'||s.type==='extruder'||s.type==='optional_extruder'||s.key==='material_diameter')return 'Se configura desde el perfil de impresora. Esta versión lamina con un extrusor y centrado automático.';return ''}
export function parseSetting(s,raw){
 let value;if(s.type==='bool'){if(typeof raw==='boolean')return raw;if(raw==='true')return true;if(raw==='false')return false;throw Error('Elegí Sí o No.');}
 if(['float','int','extruder','optional_extruder'].includes(s.type)){if(String(raw).trim()==='')throw Error('Ingresá un número.');value=Number(raw);if(!Number.isFinite(value))throw Error('Número inválido.');if(s.type!=='float'&&!Number.isInteger(value))throw Error('Debe ser entero.');if(s.minimum_value!==undefined&&Number.isFinite(Number(s.minimum_value))&&value<Number(s.minimum_value))throw Error('Mínimo: '+s.minimum_value);if(s.maximum_value!==undefined&&Number.isFinite(Number(s.maximum_value))&&value>Number(s.maximum_value))throw Error('Máximo: '+s.maximum_value);return value}
 if(s.type==='enum'){if(!Object.hasOwn(s.options||{},raw))throw Error('Opción no admitida.');return raw}
 if(['[int]','polygon','polygons'].includes(s.type)){value=typeof raw==='string'?JSON.parse(raw):raw;if(!Array.isArray(value))throw Error('Usá una lista JSON.');if(s.type==='[int]'&&!value.every(Number.isInteger))throw Error('La lista solo admite enteros.');return value}
 value=String(raw);if(value.length>12000)throw Error('Texto demasiado largo.');return value;
}
export function resolveSettings(overrides={}){
 const values={},errors={},visiting=new Set();
 function get(key){if(Object.hasOwn(values,key))return values[key];const s=catalog.settings[key];if(!s)throw Error('Dependencia desconocida: '+key);if(visiting.has(key))throw Error('Dependencia circular: '+key);visiting.add(key);let value;
 try{if(Object.hasOwn(overrides,key))value=overrides[key];else if(Object.hasOwn(s,'value'))value=typeof s.value==='string'?evaluateExpression(s.value,get):s.value;else value=s.default_value;
 if(value===undefined)throw Error('Sin valor predeterminado.');if(typeof value==='number'&&!Number.isFinite(value))throw Error('Resultado numérico inválido.');values[key]=value;return value;
 }catch(e){errors[key]=e.message;if(s.default_value!==undefined){values[key]=s.default_value;return values[key]}throw e}finally{visiting.delete(key)}}
 for(const key of Object.keys(catalog.settings))try{get(key)}catch(e){errors[key]=e.message}
 return {values,errors,get,enabled:key=>{const expr=catalog.settings[key]?.enabled;if(expr===undefined)return true;try{return typeof expr==='string'?Boolean(evaluateExpression(expr,get)):Boolean(expr)}catch{return null}}};
}
export function encodeOverrides(values){return Object.entries(values).filter(([,value])=>value!==undefined).map(([key,value])=>({key,value:Array.isArray(value)?JSON.stringify(value):value}))}
export function cleanOverrides(data){const out={};if(!data||typeof data!=='object'||Array.isArray(data))throw Error('Perfil inválido.');for(const [key,raw]of Object.entries(data)){const s=Object.hasOwn(catalog.settings,key)?catalog.settings[key]:null;if(!s||lockedReason(s))throw Error('Parámetro no editable: '+key);out[key]=parseSetting(s,raw)}return out}

export function settingBounds(setting,resolved){
 const bound=k=>{const v=setting[k];if(v===undefined)return null;try{const n=typeof v==='number'?v:evaluateExpression(v,resolved.get);return Number.isFinite(n)?n:null}catch{return null}};
 return {min:bound('minimum_value'),max:bound('maximum_value'),warningMin:bound('minimum_value_warning'),warningMax:bound('maximum_value_warning')};
}
export function validateSettingsOverrides(data,resolved=resolveSettings(data)){
 for(const [key,value]of Object.entries(data)){const s=catalog.settings[key];if(!s)throw Error('Parámetro desconocido.');parseSetting(s,value);if(typeof value==='number'){const b=settingBounds(s,resolved);if(b.min!==null&&value<b.min)throw Error(s.label+': mínimo '+b.min);if(b.max!==null&&value>b.max)throw Error(s.label+': máximo '+b.max)}}return resolved;
}

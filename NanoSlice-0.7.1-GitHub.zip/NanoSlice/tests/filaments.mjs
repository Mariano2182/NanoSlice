import assert from 'node:assert/strict';
import {filaments,validateFilament,filamentEngineSettings,filamentCompatibility,defaultEquipment,validateMaterialTemperatures,materializeRecommendation}from '../src/filaments.js';
import {defaultMachine}from '../src/machine.js';
import {inspectGcode}from '../src/gcode.js';
const eq=defaultEquipment(defaultMachine),get=id=>filaments.find(f=>f.id===id);
assert.equal(filaments.length,11);for(const p of filaments){assert.equal(validateFilament(p).id,p.id);assert.ok(p.temp>=p.tempRange[0]&&p.temp<=p.tempRange[1])}
assert.equal(filamentCompatibility(get('PLA'),defaultMachine,eq).errors.length,0);
assert.ok(filamentCompatibility(get('ABS'),defaultMachine,eq).errors.length>=2);
const capable={...defaultMachine,maxTemp:300,maxBed:120};assert.equal(filamentCompatibility(get('PC'),capable,eq).errors.length,0);
assert.ok(filamentCompatibility(get('PC'),capable,eq).warnings.some(s=>s.includes('hotend')));
assert.ok(filamentCompatibility(get('PLA'),{...defaultMachine,heated:false},eq).errors.length);
const tpu=filamentEngineSettings(get('TPU'),eq);assert.equal(tpu.retraction_enable,false);assert.equal(tpu.retraction_amount,0);assert.equal(tpu.cool_fan_speed,0);
assert.equal(filamentEngineSettings(get('PLA'),{...eq,extruder:'direct'}).retraction_amount,1);
assert.equal(materializeRecommendation({settings:{speed:'45',adhesion:'skirt'}},get('TPU')).settings.speed,'20');assert.equal(materializeRecommendation({settings:{speed:'45',adhesion:'skirt'}},get('ABS')).settings.adhesion,'brim');
const custom=validateFilament({...get('PETG'),name:'Mi PETG',brand:'Bobina prueba',temp:230,bed:70,abrasive:true});assert.equal(validateFilament(JSON.parse(JSON.stringify(custom))).id,custom.id);assert.equal(filamentCompatibility(custom,defaultMachine,eq).errors.length,0);assert.ok(filamentCompatibility(custom,defaultMachine,eq).warnings.some(s=>s.includes('abrasión')));
assert.throws(()=>validateFilament({...get('PLA'),fan:200}));assert.throws(()=>validateFilament({...get('PLA'),family:'unknown'}));assert.ok(filamentCompatibility({...get('PLA'),diameter:2.85},defaultMachine,eq).errors.length);
assert.throws(()=>validateMaterialTemperatures({material_print_temperature_layer_0:300},defaultMachine));assert.throws(()=>validateMaterialTemperatures({material_bed_temperature:100},defaultMachine));
const code='G28\nM109 S200\n;LAYER:0\nG1 X10 Y10 Z.2\nG1 X20 E1\n';assert.equal(inspectGcode(code,defaultMachine).temperatureViolations,0);assert.equal(inspectGcode('M104 S400\n'+code,defaultMachine).temperatureViolations,1);assert.equal(inspectGcode('M190 S100\n'+code,defaultMachine).temperatureViolations,1);
console.log('Filamentos aprobados: 11 perfiles, límites térmicos, equipo, TPU, recomendación, personalizados, diámetros y G-code.');

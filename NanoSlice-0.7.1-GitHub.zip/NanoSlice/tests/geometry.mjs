import assert from 'node:assert/strict';
import {BoxGeometry,Vector3,Mesh} from 'three';
import {STLExporter} from 'three/examples/jsm/exporters/STLExporter.js';
import {STLLoader} from 'three/examples/jsm/loaders/STLLoader.js';
import {groundGeometry,turnGeometry} from '../src/geometry.js';
const original=groundGeometry(new BoxGeometry(20,30,40));
function dims(g){g.computeBoundingBox();return g.boundingBox.getSize(new Vector3()).toArray().map(v=>Math.round(v*1000)/1000)}
assert.deepEqual(dims(original),[20,30,40]);assert.equal(original.boundingBox.min.z,0);
const gx=turnGeometry(original,'x');assert.deepEqual(dims(gx),[20,40,30]);assert.equal(gx.boundingBox.min.z,0);
const gy=turnGeometry(original,'y');assert.deepEqual(dims(gy),[40,30,20]);
const gz=turnGeometry(original,'z');assert.deepEqual(dims(gz),[30,20,40]);
let full=original;for(let i=0;i<4;i++)full=turnGeometry(full,'x');assert.deepEqual(dims(full),[20,30,40]);
const model=new Mesh(gx);model.scale.setScalar(.5);model.updateMatrixWorld(true);const buffer=new STLExporter().parse(model,{binary:true});const reloaded=new STLLoader().parse(buffer.buffer);assert.deepEqual(dims(reloaded),[10,20,15]);assert.equal(reloaded.boundingBox.min.z,0);
assert.deepEqual(dims(original),[20,30,40]);console.log('Orientación y exportación aprobadas: X/Y/Z, apoyo en Z=0, vuelta completa y STL con escala.');

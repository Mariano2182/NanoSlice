import assert from 'node:assert/strict';
import {catalog,resolveSettings,parseSetting,cleanOverrides,encodeOverrides,lockedReason,validateSettingsOverrides}from '../src/settings.js';
import {evaluateExpression}from '../src/expression.js';
const base={machine_extruder_count:1,machine_width:220,machine_depth:220,machine_height:250,machine_nozzle_size:.4,speed_print:40,layer_height:.2,infill_sparse_density:20,infill_pattern:'grid'};
let r=resolveSettings(base);assert.deepEqual(r.errors,{});assert.equal(Object.keys(r.values).length,Object.keys(catalog.settings).length);assert.equal(r.values.speed_wall,20);assert.equal(r.values.speed_wall_x,20);assert.equal(r.values.infill_line_distance,4);assert.equal(r.values.line_width,.4);
r=resolveSettings({...base,infill_sparse_density:40,material_flow:95});assert.equal(r.values.infill_line_distance,2);assert.equal(r.values.wall_0_material_flow,95);
r=resolveSettings({...base,speed_wall:12});assert.equal(r.values.speed_wall_x,12);
r=resolveSettings({...base,adhesion_type:'brim',brim_width:6});assert.ok(r.values.brim_line_count>0);
assert.equal(parseSetting(catalog.settings.retraction_amount,'6'),6);assert.throws(()=>parseSetting(catalog.settings.layer_height,'-1'));assert.throws(()=>parseSetting(catalog.settings.infill_pattern,'inventado'));assert.throws(()=>parseSetting(catalog.settings.infill_angles,'[1,2.5]'));assert.deepEqual(parseSetting(catalog.settings.infill_angles,'[45,135]'),[45,135]);
assert.throws(()=>cleanOverrides({machine_width:999}));assert.ok(lockedReason(catalog.settings.machine_extruder_count));assert.deepEqual(cleanOverrides({retraction_amount:6}),{retraction_amount:6});assert.equal(encodeOverrides({infill_angles:[45,135]})[0].value,'[45,135]');
assert.equal(evaluateExpression('0 if density == 0 else 100 / density',k=>({density:0})[k]),0);assert.equal(evaluateExpression('max(map(abs, extruderValues("offset")))',k=>({offset:-3})[k]),3);assert.throws(()=>evaluateExpression('__proto__.constructor("alert(1)")',()=>0));
console.log('577 ajustes resueltos: dependencias, anulaciones, flujo, relleno, brim, validación de perfiles y expresiones aprobados.');

assert.throws(()=>cleanOverrides(JSON.parse('{\"__proto__\":{}}')));
assert.throws(()=>validateSettingsOverrides({layer_height:-1}));
assert.equal(resolveSettings({...base,cool_fan_enabled:false}).values.cool_fan_speed_max,0);
assert.equal(resolveSettings({...base,retraction_speed:35}).values.retraction_prime_speed,35);
assert.equal(resolveSettings({...base,support_infill_rate:20,support_pattern:'grid'}).values.support_line_distance,4);

import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
const html=fs.readFileSync('dist/actualizar.html','utf8'),code=html.match(/<script>([\s\S]*?)<\/script>/)[1];
async function run({online=true,auth=true}={}){
 const deleted=[],unregistered=[],redirects=[],button={disabled:false},status={textContent:''};
 const caches={keys:async()=>['nanoslice-v1','nanoslice-later','unrelated-cache'],delete:async key=>deleted.push(key)};
 const location={origin:'https://test.invalid',replace:url=>redirects.push(url)};
 const navigator={onLine:online,serviceWorker:{getRegistrations:async()=>[{scope:'https://test.invalid/',unregister:async()=>unregistered.push('root')},{scope:'https://test.invalid/other/',unregister:async()=>unregistered.push('other')}]}};
 const context={document:{getElementById:id=>id==='update'?button:status},navigator,location,caches,window:{caches},fetch:async()=>({ok:true,headers:{get:()=>auth?'application/json':'text/html'},json:async()=>({version:'0.7.1'})}),Date,encodeURIComponent};
 vm.runInNewContext(code,context);await button.onclick.call(button);return {deleted,unregistered,redirects,status,button};
}
const success=await run();assert.deepEqual(success.deleted,['nanoslice-v1','nanoslice-later']);assert.deepEqual(success.unregistered,['root']);assert.match(success.redirects[0],/^\/\?version=0\.7\.1&refresh=\d+$/);
const offline=await run({online:false});assert.equal(offline.deleted.length,0);assert.equal(offline.redirects.length,0);assert.equal(offline.button.disabled,false);
const noAuth=await run({auth:false});assert.equal(noAuth.deleted.length,0);assert.equal(noAuth.unregistered.length,0);assert.match(noAuth.status.textContent,/cuenta/);
const index=fs.readFileSync('dist/index.html','utf8'),version=JSON.parse(fs.readFileSync('dist/version.json'));assert.match(version.app,/^app\.[a-f0-9]{12}\.js$/);assert.ok(fs.existsSync('dist/'+version.app));assert.ok(index.includes('src="'+version.app+'"'));assert.ok(index.includes('href="'+version.style+'"'));assert.ok(fs.existsSync('dist/'+version.style));assert.ok(index.includes('href="/actualizar.html"'));
console.log('Actualización aprobada: archivos por versión, recuperación, solo cachés propios, sin cambios en perfiles, sin borrado offline o sin sesión.');
